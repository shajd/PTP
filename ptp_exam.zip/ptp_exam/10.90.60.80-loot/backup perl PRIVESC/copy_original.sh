#!/bin/sh
for f in *.txt
do
cp -v "$f" /var/www/"${f%.txt}"$(date +%m%d%y).txt
done
