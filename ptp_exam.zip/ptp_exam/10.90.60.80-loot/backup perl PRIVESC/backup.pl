#!/usr/bin/perl

system("sh", "/root/copy.sh");
